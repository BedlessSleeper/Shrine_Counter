﻿using System;
using BepInEx;
using BepInEx.Logging;
using BepInEx.Unity.IL2CPP;
using HarmonyLib;
using Il2CppInterop.Runtime.Injection;
using UnityEngine;
using UnityEngine.UI;

namespace Shrine_Counter
{
    [BepInPlugin(GUID, MODNAME, VERSION)]
    public class Plugin : BasePlugin
    {
        public const string
            MODNAME = "Shrine_Counter",
            AUTHOR = "BedlessSleeper",
            GUID = AUTHOR + "_" + MODNAME,
            VERSION = "0.1.4";

        internal static ManualLogSource log;
        private static GameObject shrineCounterGO;

        public static int ActiveShrineCount { get; private set; } = 0;
        public static bool IsRoundActive { get; private set; } = false;

        public Plugin() => log = Log;

        public override void Load()
        {
            log.LogInfo("Shrine Counter Mod loaded!");

            // Register GUI type
            ClassInjector.RegisterTypeInIl2Cpp<ShrineCounterGUI>();

            // Patch all Harmony methods
            new Harmony(GUID).PatchAll();

            // Create the GUI
            CreateGUI();
        }

        private static void CreateGUI()
        {
            if (shrineCounterGO != null) return;

            shrineCounterGO = new GameObject("ShrineCounterGUI");
            shrineCounterGO.AddComponent<ShrineCounterGUI>();
            UnityEngine.Object.DontDestroyOnLoad(shrineCounterGO);
        }

        public static void SafeCleanup()
        {
            try
            {
                if (shrineCounterGO != null)
                {
                    UnityEngine.Object.Destroy(shrineCounterGO);
                    shrineCounterGO = null;
                    //log?.LogInfo("[ShrineCounter] GUI cleaned up.");
                }

                ActiveShrineCount = 0;
                IsRoundActive = false;
            }
            catch (Exception ex)
            {
                log?.LogError($"[ShrineCounter] Cleanup failed: {ex}");
            }
        }

        // --- Harmony Patches --- Shrine Start = Shrine Count +1

        [HarmonyPatch]
        public static class ChargeShrineStartPatch
        {
            static System.Reflection.MethodBase TargetMethod()
            {
                var type = AccessTools.TypeByName("ChargeShrine");
                return AccessTools.Method(type, "Start");
            }

            //Counts shrine shit here
            static void Postfix() => ActiveShrineCount++;
        }

        [HarmonyPatch]
        public static class ChargeShrineCompletePatch
        {
            static System.Reflection.MethodBase TargetMethod()
            {
                var type = AccessTools.TypeByName("ChargeShrine");
                return AccessTools.Method(type, "Complete");
            }

            static void Postfix() => ActiveShrineCount--;
        }

        [HarmonyPatch]
        public static class GameManager_StartPatch
        {
            static System.Reflection.MethodBase TargetMethod()
            {
                var type = AccessTools.TypeByName("GameManager");
                return AccessTools.Method(type, "Start");
            }

            static void Postfix()
            {
                ActiveShrineCount = 0;
                IsRoundActive = true;
            }
        }

        [HarmonyPatch(typeof(GameManager), "OnDied")]
        public static class GameManager_OnDiedPatch
        {
            static void Postfix()
            {
                IsRoundActive = false;
                ActiveShrineCount = 0;
            }
        }

        [HarmonyPatch(typeof(GameManager), "OnDestroy")]
        public static class GameManager_OnDestroyPatch
        {
            static void Postfix()
            {
                IsRoundActive = false;
                ActiveShrineCount = 0;
            }
        }

        // --- GUI Class --- AHHHHHHHHHHHHHH
        public class ShrineCounterGUI : MonoBehaviour
        {
            private Text textObj;
            private Canvas canvas;

            private int lastCount = -1;
            private bool lastRoundActive = false;

            void Awake() => DontDestroyOnLoad(gameObject);

            void Start()
            {
                // Create a new canvas
                GameObject canvasGO = new GameObject("ShrineCounterCanvas");
                canvas = canvasGO.AddComponent<Canvas>();
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                UnityEngine.Object.DontDestroyOnLoad(canvasGO);

                // Create the text object
                GameObject textGO = new GameObject("ShrineCounterText");
                textGO.transform.SetParent(canvasGO.transform, false);

                textObj = textGO.AddComponent<Text>();
                textObj.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                textObj.alignment = TextAnchor.UpperLeft; // anchor top-left
                textObj.horizontalOverflow = HorizontalWrapMode.Overflow;
                textObj.verticalOverflow = VerticalWrapMode.Overflow;

                // Add shadow for readability
                var shadow = textGO.AddComponent<Shadow>();
                shadow.effectColor = Color.black;
                shadow.effectDistance = new Vector2(2, -2);

                UpdateTextPositionAndSize(); // set initial position and font size
                textObj.text = $"Active Shrines: {Plugin.ActiveShrineCount}";
            }

            void Update()
            {
                if (textObj == null) return;

                // Update text when values change
                if (Plugin.ActiveShrineCount != lastCount || Plugin.IsRoundActive != lastRoundActive)
                {
                    textObj.enabled = Plugin.IsRoundActive;
                    textObj.text = $"Active Shrines: {Plugin.ActiveShrineCount}";

                    lastCount = Plugin.ActiveShrineCount;
                    lastRoundActive = Plugin.IsRoundActive;
                }
               
                // Dynamically adjust position and font size every frame in case of resolution changes
                UpdateTextPositionAndSize();
            }

            private void UpdateTextPositionAndSize()
            {
                if (textObj == null) return;

                // Anchor top-left
                textObj.rectTransform.anchorMin = new Vector2(0f, 1f);
                textObj.rectTransform.anchorMax = new Vector2(0f, 1f);
                textObj.rectTransform.pivot = new Vector2(0f, 1f);

                // Position: offset as % of screen size
                float horizontalOffset = Screen.width * 0.64f; // % Of Monitor -Lower Left Higher Right
                float verticalOffset = Screen.height * 0.039f; // % Of Monitor -Lower Up Higher Down
                textObj.rectTransform.anchoredPosition = new Vector2(horizontalOffset, -verticalOffset);

                // Font size scales with screen height
                textObj.fontSize = Mathf.RoundToInt(Screen.height * 0.025f); // 2.5% of screen height
            }

            void OnDisable() => Plugin.SafeCleanup();
            void OnDestroy() => Plugin.SafeCleanup();
        }
    }
}